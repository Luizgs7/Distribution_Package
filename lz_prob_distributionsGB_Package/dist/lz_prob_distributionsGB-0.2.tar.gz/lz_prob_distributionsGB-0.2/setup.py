from setuptools import setup

setup(name='lz_prob_distributionsGB',
      version='0.2',
      description='Gaussian and Binomial distributions',
      packages=['distributions'],
      author='Luiz Gabriel de Souza',
      author_email='luiz.gabriel.souza@hotmail.com',
      zip_safe=False)